Action()
{
	int iterations;
    int i;
    lr_save_string("3", "NumIterations");
    iterations = atoi(lr_eval_string("{NumIterations}"));
    

	lr_start_transaction("00_mainPage");

/*Correlation comment: Automatic rules - Do not change!  
Original value='41bdaa0f-1b03-4623-a5f8-8296ed424cc9' 
Name ='uuid' 
Type ='Rule' 
AppName ='ya.ru' 
RuleName ='uuid'*/
	web_reg_save_param_regexp(
		"ParamName=uuid",
		"RegExp=uuid=(.*?)&",
		LAST);

/*Correlation comment: Automatic rules - Do not change!  
Original value='e988e309b06c0ed4c89b54ed43408d9d4434ede7:1736244497566' 
Name ='csrf_token' 
Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=csrf_token",
		"RegExp=\"csrf\":\"(.*?)\"",
		LAST);

/*Correlation comment: Automatic rules - Do not change!  
Original value='5677607671736244497' 
Name ='yu' 
Type ='Rule' 
AppName ='ya.ru' 
RuleName ='yu'*/
	web_reg_save_param_regexp(
		"ParamName=yu",
		"RegExp=\"yandexuid\":\"(.*?)\"",
		LAST);


	web_reg_find("Search=All",
		"Text=HTTP/1.1 200 OK",
		LAST);

	web_url("passport", 
		"URL=https://passport.yandex.ru/passport?mode=auth&retpath=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t314.inf", 
		"Mode=HTML", 
		LAST);


	lr_end_transaction("00_mainPage",LR_AUTO);


	lr_start_transaction("01_Login");

	web_reg_find(
		"Text=data-page-type=\"auth.enter\"",
		LAST);

	web_submit_data("auth",
		"Action=https://passport.yandex.ru/auth?mode=auth&retpath=https%3A%2F%2Fsso.passport.yandex.ru%2Fprepare%3Fuuid%3D{uuid}%26goal%3Dhttps%253A%252F%252Fya.ru%252F%26finish%3Dhttps%253A%252F%252Fmail.yandex.ru%252Flite%252F",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://passport.yandex.ru/passport?mode=auth&retpath=https%3A%2F%2Fmail.yandex.ru%2Flite%2F",
		"Snapshot=t315.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=retpath", "Value=https://sso.passport.yandex.ru/prepare?uuid={uuid}&goal=https%3A%2F%2Fya.ru%2F&finish=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", ENDITEM,
		"Name=fretpath", "Value=", ENDITEM,
		"Name=clean", "Value=", ENDITEM,
		"Name=service", "Value=", ENDITEM,
		"Name=origin", "Value=", ENDITEM,
		"Name=policy", "Value=", ENDITEM,
		"Name=is_pdd", "Value=", ENDITEM,
		"Name=csrf_token", "Value={csrf_token}", ENDITEM,
		"Name=login", "Value={login}", ENDITEM,
		"Name=hidden-password", "Value=", ENDITEM,
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_submit_data("auth_2",
		"Action=https://passport.yandex.ru/auth?mode=auth&retpath=https%3A%2F%2Fsso.passport.yandex.ru%2Fprepare%3Fuuid%3D{uuid}%26goal%3Dhttps%253A%252F%252Fya.ru%252F%26finish%3Dhttps%253A%252F%252Fmail.yandex.ru%252Flite%252F",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://passport.yandex.ru/auth?mode=auth&retpath=https%3A%2F%2Fsso.passport.yandex.ru%2Fprepare%3Fuuid%3D{uuid}%26goal%3Dhttps%253A%252F%252Fya.ru%252F%26finish%3Dhttps%253A%252F%252Fmail.yandex.ru%252Flite%252F",
		"Snapshot=t316.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=login", "Value={login}", ENDITEM,
		"Name=passwd", "Value={pswd}", ENDITEM,
		"Name=retpath", "Value=https://sso.passport.yandex.ru/prepare?uuid={uuid}&goal=https%3A%2F%2Fya.ru%2F&finish=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", ENDITEM,
		LAST);

	web_reg_find(
		"Text=href=\"https://yastatic.net/s3/mail/lite/",
		LAST);

	web_url("lite",
		"URL=https://mail.yandex.ru/lite/",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://sso.ya.ru/sync?uuid={uuid}&finish=https%3A%2F%2Fmail.yandex.ru%2Flite%2F",
		"Snapshot=t318.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("01_Login",LR_AUTO);
	

	lr_start_transaction("02_newPageLetter");

/*Correlation comment: Automatic rules - Do not change!  
Original value='d3be55dad98306d01cbf9c484f78f896' 
Name ='compose_check' 
Type ='Rule' 
AppName ='ya.ru' 
RuleName ='compose_check'*/
	web_reg_save_param_regexp(
		"ParamName=compose_check",
		"RegExp=name=\"compose_check\"\\ value=\"(.*?)\"",
		LAST);

/*Correlation comment: Automatic rules - Do not change!  
Original value='38nNkypOuKubnSY0rW5lGxHNq5o=!m5nqmizm!5pRlWwbqLvkkBaqmx/ZHJmzwlDk=!3' 
Name ='_ckey' 
Type ='Rule' 
AppName ='ya.ru' 
RuleName ='_ckey'*/
	web_reg_save_param_regexp(
		"ParamName=_ckey",
		"RegExp=name=\"_ckey\"\\ value=\"(.*?)\"",
		"Ordinal=1",
		SEARCH_FILTERS,
		"Scope=Body",
		"RequestUrl=*/retpath=%2F*",
		LAST);

	web_reg_find("Search=All",
		"Text=HTTP/1.1 200 OK",
		LAST);

	web_url("retpath=%2F", 
		"URL=https://mail.yandex.ru/lite/compose/retpath=%2F", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://mail.yandex.ru/lite/", 
		"Snapshot=t320.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("02_newPageLetter",LR_AUTO);

 for (i = 0; i < iterations; i++) {
	
	lr_start_transaction("03_sendLetter");

	web_reg_find(
		"Text=test{time}",
		LAST);

	
	web_submit_data("compose-action.xml",
		"Action=https://mail.yandex.ru/lite/compose-action.xml",
		"Method=POST",
		"EncType=multipart/form-data",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://mail.yandex.ru/lite/compose/retpath=%2F",
		"Snapshot=t327.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=request", "Value=", ENDITEM,
		"Name=to", "Value={addressee}, ", ENDITEM,
		"Name=cc", "Value=", ENDITEM,
		"Name=bcc", "Value=", ENDITEM,
		"Name=subj", "Value=QE-Lesson3", ENDITEM,
		"Name=send", "Value=test{time}", ENDITEM,
		"Name=att", "Value=", "File=yes", ENDITEM,
		"Name=doit", "Value=Отправить", ENDITEM,
		"Name=compose_check", "Value={compose_check}", ENDITEM,
		"Name=_ckey", "Value={_ckey}", ENDITEM,
		"Name=ttype", "Value=plain", ENDITEM,
		"Name=_handlers", "Value=do-send", ENDITEM,
		"Name=style", "Value=lite", ENDITEM,
		"Name=fid", "Value=", ENDITEM,
		"Name=from_mailbox", "Value={login}", ENDITEM,
		"Name=from_name", "Value=Дмитри�\xB9 Казаков", ENDITEM,
		"Name=mark_as", "Value=", ENDITEM,
		"Name=mark_ids", "Value=", ENDITEM,
		"Name=retpath", "Value=inbox", ENDITEM,
		"Name=nohl", "Value=", ENDITEM,
		LAST);

	lr_end_transaction("03_sendLetter",LR_AUTO);
	
}

	lr_start_transaction("04_Logout");

/*Correlation comment: Automatic rules - Do not change!  
Original value='0ed7757a-9fc6-4083-a93e-230d9543f6a5' 
Name ='uuid_1' 
Type ='Rule' 
AppName ='ya.ru' 
RuleName ='uuid'*/
	web_reg_save_param_regexp(
		"ParamName=uuid_1",
		"RegExp=uuid=(.*?)&",
		LAST);

	web_url("passport_2",
		"URL=https://passport.yandex.ru/passport?mode=logout&yu={yu}&retpath=https%3A%2F%2Fya.ru",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://mail.yandex.ru/lite/inbox?ids=&executed_action=message_send",
		"Snapshot=t329.inf",
		"Mode=HTML",
		LAST);

	web_reg_find("Search=Body",
		"Text=href=\"//yandex.ru/",
		LAST);

	web_url("ya.ru",
		"URL=https://ya.ru/",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://sso.ya.ru/sync?uuid={uuid_1}&finish=https%3A%2F%2Fya.ru",
		"Snapshot=t331.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("04_Logout",LR_AUTO);

	return 0;
}
Action()
{

	lr_start_transaction("1_transaction");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("passport", 
		"URL=https://passport.yandex.ru/passport?mode=auth&retpath=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t314.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://yastatic.net/s3/passport-auth-customs/customs/v1.174.4/passport.auth.customs.css", "Referer=https://passport.yandex.ru/passport?mode=auth&retpath=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", ENDITEM, 
		"Url=https://yastatic.net/islands/_/g0MeJlAWVRZjlLOLzhOGwwDQzKY.woff", "Referer=https://passport.yandex.ru/passport?mode=auth&retpath=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", ENDITEM, 
		"Url=https://yastatic.net/islands/_/7RkupUWVEcepjeZPFv1xCDdQFhc.woff", "Referer=https://passport.yandex.ru/passport?mode=auth&retpath=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", ENDITEM, 
		"Url=https://yastatic.net/s3/passport-auth-customs/customs/_/5e377c3c.jpg", "Referer=https://passport.yandex.ru/passport?mode=auth&retpath=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", ENDITEM, 
		"Url=https://yastatic.net/islands/_/6n8FrCwGXwQ5ZumBk1SCxOl2ec8.woff", "Referer=https://passport.yandex.ru/passport?mode=auth&retpath=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", ENDITEM, 
		"Url=https://yastatic.net/s3/passport-static/core/v1.188.15/i/authv2/all-social-icon.svg", "Referer=https://passport.yandex.ru/passport?mode=auth&retpath=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", ENDITEM, 
		"Url=https://yastatic.net/s3/passport-static/core/v1.188.15/i/authv2/qr-icon.svg", "Referer=https://passport.yandex.ru/passport?mode=auth&retpath=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", ENDITEM, 
		LAST);

	lr_end_transaction("1_transaction",LR_AUTO);

	lr_think_time(7);

	lr_start_transaction("2_transaction");

	web_submit_data("auth", 
		"Action=https://passport.yandex.ru/auth?mode=auth&retpath=https%3A%2F%2Fsso.passport.yandex.ru%2Fprepare%3Fuuid%3D41bdaa0f-1b03-4623-a5f8-8296ed424cc9%26goal%3Dhttps%253A%252F%252Fya.ru%252F%26finish%3Dhttps%253A%252F%252Fmail.yandex.ru%252Flite%252F", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://passport.yandex.ru/passport?mode=auth&retpath=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", 
		"Snapshot=t315.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=retpath", "Value=https://sso.passport.yandex.ru/prepare?uuid=41bdaa0f-1b03-4623-a5f8-8296ed424cc9&goal=https%3A%2F%2Fya.ru%2F&finish=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", ENDITEM, 
		"Name=fretpath", "Value=", ENDITEM, 
		"Name=clean", "Value=", ENDITEM, 
		"Name=service", "Value=", ENDITEM, 
		"Name=origin", "Value=", ENDITEM, 
		"Name=policy", "Value=", ENDITEM, 
		"Name=is_pdd", "Value=", ENDITEM, 
		"Name=csrf_token", "Value=e988e309b06c0ed4c89b54ed43408d9d4434ede7:1736244497566", ENDITEM, 
		"Name=login", "Value=kaz4kov.dmitr@yandex.ru", ENDITEM, 
		"Name=hidden-password", "Value=", ENDITEM, 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_submit_data("auth_2", 
		"Action=https://passport.yandex.ru/auth?mode=auth&retpath=https%3A%2F%2Fsso.passport.yandex.ru%2Fprepare%3Fuuid%3D41bdaa0f-1b03-4623-a5f8-8296ed424cc9%26goal%3Dhttps%253A%252F%252Fya.ru%252F%26finish%3Dhttps%253A%252F%252Fmail.yandex.ru%252Flite%252F", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://passport.yandex.ru/auth?mode=auth&retpath=https%3A%2F%2Fsso.passport.yandex.ru%2Fprepare%3Fuuid%3D41bdaa0f-1b03-4623-a5f8-8296ed424cc9%26goal%3Dhttps%253A%252F%252Fya.ru%252F%26finish%3Dhttps%253A%252F%252Fmail.yandex.ru%252Flite%252F", 
		"Snapshot=t316.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=login", "Value=kaz4kov.dmitr@yandex.ru", ENDITEM, 
		"Name=passwd", "Value=MorFun78", ENDITEM, 
		"Name=retpath", "Value=https://sso.passport.yandex.ru/prepare?uuid=41bdaa0f-1b03-4623-a5f8-8296ed424cc9&goal=https%3A%2F%2Fya.ru%2F&finish=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", ENDITEM, 
		LAST);

	web_submit_data("sync", 
		"Action=https://sso.ya.ru/sync?uuid=41bdaa0f-1b03-4623-a5f8-8296ed424cc9&finish=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://sso.passport.yandex.ru/prepare?uuid=41bdaa0f-1b03-4623-a5f8-8296ed424cc9&goal=https%3A%2F%2Fya.ru%2F&finish=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", 
		"Snapshot=t317.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=goal", "Value=https://ya.ru/", ENDITEM, 
		"Name=container", "Value="
		"1736244606.10151503.K2t8UFGlLaxeYdjR._RnX9BNF1b3_j_DkGLy2iZKoGucCevF19cwXj7fswxjqfX7MVrWdDwDJDkgRYlojjoKt4kBEnHz0W3qcWTwGiQJUA1wIhldYmjMGw7L8r4-rPjJTFmArzWaPvNu_P0k-3KsJZYTWX7t_TGaHtOAIm9APsFNXKoh8VPbkFNlhda4ro5i2C1_wrwdy4nBr0_3-nBTM9aMWvpsmrSZT740QRjBY4mRgIzbjM7eog92ETpT0VQAB94iCPTc1TdyRpZ8TxhMxJjyCt0F0Pij-G1j4yz9_4Ro5DC9xhv0j_e4r1QsB1J7XwqkUy-WJUYmX9tOhl8SpO4KEVyOKJSCXfalgboYz8mvlTdYkL3KhkJH1qfyfmy8hte_Ld9jPKKrdCuQk00hcPqITRJbek7nKpj33_rOFBICaHks2c9Q-39qmAzUHqyL1qBPf4LCn-aQZHYT0Qg2ZLHXCqeVSl39YT"
		"wsHKR56QI2qPrMo8GyoO5Yz5b4tCdEFtn2FHyHATIE9aOkCktCRGijWkFf857gB2O1jlcfAMDml4DqJn_bohz7StwyC-sNyveZXMJm05UA4ihlMhe8-HooPk50Uc7JBDR2GOYpuM4ZG1iz4JCzOQGB4J5gyfMuFw8c3tPLSkAGx9Gu4olDPgm-4jDlb8HluLlmJsZ_WrHXRZJvNuZyPTUxbbrUdevVJ6r_QyDx4Vv43hR1km437ih-k-Iki9iDPDb507JZVM_n4BPAKqRs0Z-TbJFZkSUXVll4ZZ6cgaPxxYX6fm_gfYW8E6OqXYz62goTr9bFrP_1ZQswGy1yUwoqoDKxaJYo3yyw3Z15IOn-l2x3YqM8P2Aa5K-kwN2o0Llq7NologhzrVBiRx_fZPAcR6XozZEqfSs6RH5CFUluiTKF4NmKav4ZK19xxuQ0a8iCgp39WWnioW9rafo0wmLuzm01fQw4uG0TnXajU74PV4DNvYeJ2Jbq"
		"zMInJeJXg7hUNoH7RjjX9YvUjrQcakJrNi640AWYMCL-V0_SG1lAUWK8iY_SKlRTsl4Y_xU50b-1bTEXvZnEQ4Y450ffP1RKQxBRtS7V-gzEC8zb6UXbmuMWLivxrJNVmiZOqAMzw_Ig_dxAc0DNDiYSUt_-W1n8tNrhBIAnqYiUS8Z363p-0utWL-WU7hSVyetXVDuealEhcKj-wAXgaikvTSEMWG7jM8kkJ2HRmxR5AbgypZw42by_N2Ci-QV1m7Isw_OeriRTB0PSO1Gj5H7YEInWlZ-dOKvfUEODKozydMkGIUR8Q--4hjYwe_vGVLvuOeEPfTJYsXcEszl7xXeVlX8uBxubOxUZijlN7j2ImFJoFq7X_ERuYpzTLNJIl7syI9IpouSivyTQGNCpAAxFBlx31zY69zrlnrPopSjk_gQlgJItUuIUvLfWjgXj8toFpcgaBCp8_l_T6my47uz1EnpQ0nnx_5Ts5Ei6Vqe1ZyG1YmUOQ7"
		"wVAhsqIktG36QLdLI5rfiq0BJZByUMxR4VDOQh6Ep8XgfvTC_cBmnlLsSsOE21f_ZDxBlgRscS2SCRjJ8YwGRuxSQDYa9LdzhjRkPCMN8InYCmvxYbMYGCVRsI0D1aS7uS8-Re2lcKI08152mqyGm_ZJHMgqZDdWveXuHq8gjrFvTsh7SrqJiqvjB2bPQ92K6ueSuTbRrlx4bqVc-jO4eOB8_ofMK4nc3oeQTJbBkjRmqonrUY5xtgGmLNCfR8zENHf0_kTEJHhbTwmDCtGyRLcFKTvl3ZbPnLaCRE2UAQ6K65fQrBnxJ12uIBgNsi-D8COUaW0MYGPr-M_zms.M3G8lkZ86Rb3yd-gNhcGZg", ENDITEM, 
		LAST);

	lr_think_time(4);

	web_url("lite", 
		"URL=https://mail.yandex.ru/lite/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://sso.ya.ru/sync?uuid=41bdaa0f-1b03-4623-a5f8-8296ed424cc9&finish=https%3A%2F%2Fmail.yandex.ru%2Flite%2F", 
		"Snapshot=t318.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://yastatic.net/s3/mail/lite/_/McavqyOT-yCT4x0wvdbDCIxIphg.png", ENDITEM, 
		"Url=https://yastatic.net/s3/mail/lite/_/1OYsyKle3nTsnm7Dpg26_0S_iyg.png", ENDITEM, 
		"Url=https://yastatic.net/s3/mail/lite/_/UlfClH7m6Sj10jLQ5KxM5cSk5cc.png", ENDITEM, 
		"Url=https://mc.yandex.ru/metrika/watch.js", ENDITEM, 
		"Url=https://mc.yandex.ru/metrika/advert.gif", ENDITEM, 
		"Url=https://mc.yandex.ru/clmap/16082914?page-url=https%3A%2F%2Fmail.yandex.ru%2Flite%2F&pointer-click=rn%3A430829774%3Ax%3A38283%3Ay%3A40068%3At%3A64%3Ap%3AN%3BWAAFA1A1A%3AX%3A248%3AY%3A70&browser-info=u%3A1736244561989052703%3Av%3A1551%3Avf%3Afqngs4ku2ry4ydu78wzu8osbsm7%3Arqnl%3A1%3Ast%3A1736244567&t=gdpr(13-0)ti(4)", ENDITEM, 
		LAST);

	lr_end_transaction("2_transaction",LR_AUTO);

	web_add_header("Origin", 
		"https://mail.yandex.ru");

	web_url("16082914", 
		"URL=https://mc.yandex.ru/watch/16082914?wmode=7&page-url=https%3A%2F%2Fmail.yandex.ru%2Flite%2F&page-ref=https%3A%2F%2Fsso.ya.ru%2Fsync%3Fuuid%3D41bdaa0f-1b03-4623-a5f8-8296ed424cc9%26finish%3Dhttps%253A%252F%252Fmail.yandex.ru%252Flite%252F&charset=utf-8&site-info=%7B%22lang%22%3A%22ru%22%2C%22skin%22%3A%22lite%22%7D&ut=noindex&uah=che%0A0&browser-info="
		"pv%3A1%3Avf%3Afqngs4ku2ry4ydu78wzu8osbsm7%3Afu%3A0%3Aen%3Autf-8%3Ala%3Aru-RU%3Av%3A1551%3Acn%3A1%3Adp%3A0%3Als%3A648629984267%3Ahid%3A733113785%3Az%3A180%3Ai%3A20250107130920%3Aet%3A1736244561%3Ac%3A1%3Arn%3A547316099%3Arqn%3A1%3Au%3A1736244561989052703%3Aw%3A984x514%3As%3A1600x900x24%3Ask%3A1%3Aj%3A1%3Ads%3A0%2C0%2C5%2C144%2C1%2C0%2C%2C1920%2C10%2C%2C%2C%2C6594%3Aco%3A0%3Ans%3A1736244551083%3Arqnl%3A1%3Ast%3A1736244561&t=gdpr(13-0)clc(0-0-0)rqnt(1)aw(1)rcm(0)yu(5677607671736244497)cdl(na)eco"
		"(168960)ti(2)", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/lite/", 
		"Snapshot=t319.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("3_transaction");

	web_url("retpath=%2F", 
		"URL=https://mail.yandex.ru/lite/compose/retpath=%2F", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://mail.yandex.ru/lite/", 
		"Snapshot=t320.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://mc.yandex.ru/clmap/16082914?page-url=https%3A%2F%2Fmail.yandex.ru%2Flite%2Fcompose%2Fretpath%3D%252F&pointer-click=rn%3A251390245%3Ax%3A18265%3Ay%3A31628%3At%3A90%3Ap%3APAA%5D1b%5C%5BAA1FA1A1A%3AX%3A454%3AY%3A108&browser-info=u%3A1736244561989052703%3Av%3A1551%3Avf%3Afqngs4ku2ry4ydu78wzu8osbsm7%3Arqnl%3A1%3Ast%3A1736244577&t=gdpr(13-0)ti(4)", ENDITEM, 
		"Url=https://mc.yandex.ru/clmap/16082914?page-url=https%3A%2F%2Fmail.yandex.ru%2Flite%2Fcompose%2Fretpath%3D%252F&pointer-click=rn%3A741315820%3Ax%3A22844%3Ay%3A17467%3At%3A120%3Ap%3A%3AX%3A343%3AY%3A137&browser-info=u%3A1736244561989052703%3Av%3A1551%3Avf%3Afqngs4ku2ry4ydu78wzu8osbsm7%3Arqnl%3A1%3Ast%3A1736244580&t=gdpr(13-0)ti(4)", ENDITEM, 
		"Url=https://mc.yandex.ru/clmap/16082914?page-url=https%3A%2F%2Fmail.yandex.ru%2Flite%2Fcompose%2Fretpath%3D%252F&pointer-click=rn%3A421238975%3Ax%3A7828%3Ay%3A31628%3At%3A127%3Ap%3APAA%5D1b3%5C%5BAA1FA1A1A%3AX%3A342%3AY%3A143&browser-info=u%3A1736244561989052703%3Av%3A1551%3Avf%3Afqngs4ku2ry4ydu78wzu8osbsm7%3Arqnl%3A1%3Ast%3A1736244581&t=gdpr(13-0)ti(4)", ENDITEM, 
		"Url=https://mc.yandex.ru/clmap/16082914?page-url=https%3A%2F%2Fmail.yandex.ru%2Flite%2Fcompose%2Fretpath%3D%252F&pointer-click=rn%3A642239193%3Ax%3A11181%3Ay%3A11890%3At%3A163%3Ap%3A%5EAA1FA1A1A%3AX%3A344%3AY%3A197&browser-info=u%3A1736244561989052703%3Av%3A1551%3Avf%3Afqngs4ku2ry4ydu78wzu8osbsm7%3Arqnl%3A1%3Ast%3A1736244584&t=gdpr(13-0)ti(4)", ENDITEM, 
		"Url=https://mc.yandex.ru/clmap/16082914?page-url=https%3A%2F%2Fmail.yandex.ru%2Flite%2Fcompose%2Fretpath%3D%252F&pointer-click=rn%3A763351219%3Ax%3A35270%3Ay%3A40382%3At%3A307%3Ap%3AP1AAA1FA1A1A%3AX%3A263%3AY%3A404&browser-info=u%3A1736244561989052703%3Av%3A1551%3Avf%3Afqngs4ku2ry4ydu78wzu8osbsm7%3Arqnl%3A1%3Ast%3A1736244599&t=gdpr(13-0)ti(4)", ENDITEM, 
		LAST);

	web_add_header("Origin", 
		"https://mail.yandex.ru");

	web_url("16082914_2", 
		"URL=https://mc.yandex.ru/watch/16082914?wmode=7&page-url=https%3A%2F%2Fmail.yandex.ru%2Flite%2Fcompose%2Fretpath%3D%252F&page-ref=https%3A%2F%2Fmail.yandex.ru%2Flite%2F&charset=utf-8&site-info=%7B%22lang%22%3A%22ru%22%2C%22skin%22%3A%22lite%22%7D&ut=noindex&uah=che%0A0&browser-info="
		"pv%3A1%3Avf%3Afqngs4ku2ry4ydu78wzu8osbsm7%3Afu%3A0%3Aen%3Autf-8%3Ala%3Aru-RU%3Av%3A1551%3Acn%3A1%3Adp%3A0%3Als%3A648629984267%3Ahid%3A698452192%3Az%3A180%3Ai%3A20250107130928%3Aet%3A1736244568%3Ac%3A1%3Arn%3A411878386%3Arqn%3A2%3Au%3A1736244561989052703%3Aw%3A984x514%3As%3A1600x900x24%3Ask%3A1%3Aj%3A1%3Ads%3A0%2C0%2C2%2C75%2C2%2C0%2C%2C%2C%2C%2C%2C%2C%3Aco%3A0%3Ans%3A1736244567486%3Aadb%3A2%3Arqnl%3A1%3Ast%3A1736244568&t=gdpr(13-0)clc(0-0-0)rqnt(1)aw(1)rcm(0)yu(5677607671736244497)cdl(na)eco"
		"(168960)ti(2)", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/lite/compose/retpath=%2F", 
		"Snapshot=t321.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://mail.yandex.ru/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	lr_end_transaction("3_transaction",LR_AUTO);

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("batch", 
		"URL=https://mail.yandex.ru/lite/api/batch?client_name=LITE&client_version=3.10.0&connection_id=LITE-79527044-1736244564000", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/lite/compose/retpath=%2F", 
		"Snapshot=t322.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"methods\":[{\"name\":\"suggest-contacts\",\"params\":{\"text\":\"q\"}}]}", 
		LAST);

	web_custom_request("batch_2", 
		"URL=https://mail.yandex.ru/lite/api/batch?client_name=LITE&client_version=3.10.0&connection_id=LITE-79527044-1736244564000", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/lite/compose/retpath=%2F", 
		"Snapshot=t323.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"methods\":[{\"name\":\"suggest-contacts\",\"params\":{\"text\":\"q\"}}]}", 
		LAST);

	web_custom_request("batch_3", 
		"URL=https://mail.yandex.ru/lite/api/batch?client_name=LITE&client_version=3.10.0&connection_id=LITE-79527044-1736244564000", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/lite/compose/retpath=%2F", 
		"Snapshot=t324.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"methods\":[{\"name\":\"suggest-contacts\",\"params\":{\"text\":\"qs\"}}]}", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	web_add_auto_header("Origin", 
		"https://mail.yandex.ru");

	lr_think_time(7);

	web_submit_data("1", 
		"Action=https://mc.yandex.ru/watch/16082914/1?page-url=https%3A%2F%2Fmail.yandex.ru%2Flite%2Fcompose%2Fretpath%3D%252F&charset=utf-8&ut=noindex&hittoken=1736244565_b7a17553843381b3b515232fd38b8f5c22a8346016557d2b3ae7d53e1b9f66d1&browser-info="
		"nb%3A1%3Acl%3A111%3Aar%3A1%3Avf%3Afqngs4ku2ry4ydu78wzu8osbsm7%3Afu%3A1%3Aen%3Autf-8%3Ala%3Aru-RU%3Av%3A1551%3Acn%3A1%3Adp%3A0%3Als%3A648629984267%3Ahid%3A698452192%3Az%3A180%3Ai%3A20250107130952%3Aet%3A1736244592%3Ac%3A1%3Arn%3A557862901%3Arqn%3A3%3Au%3A1736244561989052703%3Aw%3A984x514%3As%3A1600x900x24%3Ask%3A1%3Aj%3A1%3Ads%3A%2C%2C%2C%2C%2C%2C%2C251%2C9%2C9817%2C9817%2C0%2C677%3Aco%3A0%3Aeu%3A0%3Ans%3A1736244567486%3Aadb%3A2%3Arqnl%3A1%3Ast%3A1736244592&t=gdpr(13-0)mc(cm-1-tl-1-atb-1)clc"
		"(4-370-146)rqnt(2)aw(1)rcm(0)yu(5677607671736244497)cdl(na)eco(168960)dss(2)ti(2)", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/lite/compose/retpath=%2F", 
		"Snapshot=t325.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=site-info", "Value={\"__ym\":{\"ct.e\":\"ns\"}}", ENDITEM, 
		LAST);

	lr_start_transaction("4_transaction");

	web_submit_data("1_2", 
		"Action=https://mc.yandex.ru/watch/16082914/1?page-url=form%3A%2F%2Fmail.yandex.ru%2F%3Fp%3DFA1A1A&page-ref=https%3A%2F%2Fmail.yandex.ru%2Flite%2Fcompose%2Fretpath%3D%252F&charset=utf-8&ut=noindex&uah=che%0A0&hittoken=1736244565_b7a17553843381b3b515232fd38b8f5c22a8346016557d2b3ae7d53e1b9f66d1&browser-info="
		"ar%3A1%3Avf%3Afqngs4ku2ry4ydu78wzu8osbsm7%3Afu%3A3%3Aen%3Autf-8%3Ala%3Aru-RU%3Av%3A1551%3Acn%3A1%3Adp%3A0%3Als%3A648629984267%3Ahid%3A698452192%3Az%3A180%3Ai%3A20250107130958%3Aet%3A1736244599%3Ac%3A1%3Arn%3A626002113%3Arqn%3A4%3Au%3A1736244561989052703%3Aw%3A984x514%3As%3A1600x900x24%3Ask%3A1%3Aj%3A1%3Aco%3A0%3Aeu%3A0%3Ans%3A1736244567486%3Aadb%3A2%3Arqnl%3A1%3Ast%3A1736244599&t=gdpr(13-0)mc(cm-1-tl-1-atb-1)clc(5-349-197)rqnt(3)aw(1)rcm(0)yu(5677607671736244497)cdl(na)eco(168960)dss(2)ti(2)", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=image/gif", 
		"Referer=https://mail.yandex.ru/lite/compose/retpath=%2F", 
		"Snapshot=t326.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=site-info", "Value={\"__ym\":{\"ite\":1}}", ENDITEM, 
		LAST);

	web_revert_auto_header("Origin");

	web_submit_data("compose-action.xml", 
		"Action=https://mail.yandex.ru/lite/compose-action.xml", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://mail.yandex.ru/lite/compose/retpath=%2F", 
		"Snapshot=t327.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=request", "Value=", ENDITEM, 
		"Name=to", "Value=qsc1986@mail.ru, ", ENDITEM, 
		"Name=cc", "Value=", ENDITEM, 
		"Name=bcc", "Value=", ENDITEM, 
		"Name=subj", "Value=rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr", ENDITEM, 
		"Name=send", "Value=uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu", ENDITEM, 
		"Name=att", "Value=", "File=Yes", ENDITEM, 
		"Name=doit", "Value=Отправить", ENDITEM, 
		"Name=compose_check", "Value=d3be55dad98306d01cbf9c484f78f896", ENDITEM, 
		"Name=_ckey", "Value=38nNkypOuKubnSY0rW5lGxHNq5o=!m5nqmizm!5pRlWwbqLvkkBaqmx/ZHJmzwlDk=!3", ENDITEM, 
		"Name=ttype", "Value=plain", ENDITEM, 
		"Name=_handlers", "Value=do-send", ENDITEM, 
		"Name=style", "Value=lite", ENDITEM, 
		"Name=fid", "Value=", ENDITEM, 
		"Name=from_mailbox", "Value=kaz4kov.dmitr@yandex.ru", ENDITEM, 
		"Name=from_name", "Value=Дмитри�\xB9 Казаков", ENDITEM, 
		"Name=mark_as", "Value=", ENDITEM, 
		"Name=mark_ids", "Value=", ENDITEM, 
		"Name=retpath", "Value=inbox", ENDITEM, 
		"Name=nohl", "Value=", ENDITEM, 
		LAST);

	web_add_header("Origin", 
		"https://mail.yandex.ru");

	web_url("16082914_3", 
		"URL=https://mc.yandex.ru/watch/16082914?wmode=7&page-url=https%3A%2F%2Fmail.yandex.ru%2Flite%2Finbox%3Fids%3D%26executed_action%3Dmessage_send&page-ref=https%3A%2F%2Fmail.yandex.ru%2Flite%2Fcompose%2Fretpath%3D%252F&charset=utf-8&site-info=%7B%22lang%22%3A%22ru%22%2C%22skin%22%3A%22lite%22%7D&ut=noindex&uah=che%0A0&browser-info="
		"pv%3A1%3Avf%3Afqngs4ku2ry4ydu78wzu8osbsm7%3Afu%3A0%3Aen%3Autf-8%3Ala%3Aru-RU%3Av%3A1551%3Acn%3A1%3Adp%3A0%3Als%3A648629984267%3Ahid%3A629405167%3Az%3A180%3Ai%3A20250107130959%3Aet%3A1736244600%3Ac%3A1%3Arn%3A653765697%3Arqn%3A5%3Au%3A1736244561989052703%3Aw%3A984x514%3As%3A1600x900x24%3Ask%3A1%3Aj%3A1%3Ads%3A0%2C0%2C1%2C74%2C416%2C414%2C1%2C%2C%2C%2C%2C%2C%3Aco%3A0%3Ans%3A1736244598877%3Aadb%3A2%3Arqnl%3A1%3Ast%3A1736244600&t=gdpr(13-0)clc(0-0-0)rqnt(1)aw(1)rcm(0)yu(5677607671736244497)cdl(na)eco"
		"(168960)ti(2)", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://mail.yandex.ru/lite/inbox?ids=&executed_action=message_send", 
		"Snapshot=t328.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=16082914?page-url=https%3A%2F%2Fpassport.yandex.ru%2Fpassport%3Fmode%3Dlogout%26yu%3D5677607671736244497%26retpath%3Dhttps%253A%252F%252Fya.ru&page-ref=https%3A%2F%2Fmail.yandex.ru%2Flite%2Finbox%3Fids%3D%26executed_action%3Dmessage_send&charset=utf-8&ut=noindex&uah=che%0A0&hittoken=1736244597_42ee13d6862c1a38d9008116f2c17b021e4118fbce90a79733184ceb9de5f0d3&browser-info="
		"ite%3A1%3Aln%3A1%3Avf%3Afqngs4ku2ry4ydu78wzu8osbsm7%3Afu%3A3%3Aen%3Autf-8%3Ala%3Aru-RU%3Av%3A1551%3Acn%3A1%3Adp%3A0%3Als%3A648629984267%3Ahid%3A629405167%3Az%3A180%3Ai%3A20250107131007%3Aet%3A1736244608%3Ac%3A1%3Arn%3A38890457%3Arqn%3A6%3Au%3A1736244561989052703%3Aw%3A984x514%3As%3A1600x900x24%3Ask%3A1%3Aj%3A1%3Ads%3A%2C%2C%2C%2C%2C%2C%2C116%2C5%2C908%2C908%2C1%2C883%3Aco%3A0%3Aeu%3A0%3Ans%3A1736244598877%3Aadb%3A2%3Arqnl%3A1%3Ast%3A1736244608&t=gdpr(13-0)mc(cm-1-tl-1-atb-1)clc(1-932-11)rqnt(2)aw"
		"(1)rcm(0)yu(5677607671736244497)cdl(na)eco(168960)dss(2)ti(2)", "Referer=https://mail.yandex.ru/lite/inbox?ids=&executed_action=message_send", ENDITEM, 
		"Url=../clmap/16082914?page-url=https%3A%2F%2Fmail.yandex.ru%2Flite%2Finbox%3Fids%3D%26executed_action%3Dmessage_send&pointer-click=rn%3A949742043%3Ax%3A20305%3Ay%3A31164%3At%3A81%3Ap%3A%3B1A2AA%3AX%3A932%3AY%3A11&browser-info=u%3A1736244561989052703%3Av%3A1551%3Avf%3Afqngs4ku2ry4ydu78wzu8osbsm7%3Arqnl%3A1%3Ast%3A1736244608&t=gdpr(13-0)ti(4)", "Referer=https://mail.yandex.ru/lite/inbox?ids=&executed_action=message_send", ENDITEM, 
		LAST);

	lr_end_transaction("4_transaction",LR_AUTO);

	lr_start_transaction("5_transaction");

	web_url("passport_2", 
		"URL=https://passport.yandex.ru/passport?mode=logout&yu=5677607671736244497&retpath=https%3A%2F%2Fya.ru", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://mail.yandex.ru/lite/inbox?ids=&executed_action=message_send", 
		"Snapshot=t329.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_data("sync_2", 
		"Action=https://sso.ya.ru/sync?uuid=0ed7757a-9fc6-4083-a93e-230d9543f6a5&finish=https%3A%2F%2Fya.ru", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://sso.passport.yandex.ru/prepare?uuid=0ed7757a-9fc6-4083-a93e-230d9543f6a5&goal=https%3A%2F%2Fya.ru%2F&finish=https%3A%2F%2Fya.ru", 
		"Snapshot=t330.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=goal", "Value=https://ya.ru/", ENDITEM, 
		"Name=container", "Value="
		"1736244665.10151503.SaDmUxLGXCwB1u3g.8MPSzg95TPLDwtS3eTXAoqfGt2yHMBht5X_w8x6K5PummeAAgwbKD_t6cPTIwecb7wHWrVuzdTgLBUXtyn0oGDeC7W2pA5FS5XQc8m2RVbgq6M2nGVlA6y8Ez9pQ00OyMISW-bITrsOjqjH4jEwyL7R2lBUO1pNCXXIyX6GtB9CshQYjZD6NAgp-w32QFt1bb7gRut4hNvZblzGakjt4TOvUTtCRNidTviVI4foeQ2-BVs_3D1hKqsYtu6lENm-EBoG43VgZEuU1sFR4GCbeCcNG0weM9j1RUbr1WTzgdtsdfQ27KLdTiIkfvbouABxhA8zkFoE5HxuGd-eCrfGAGd6puZmVXc7OAsSvsJowz4wCWuTAqgaAfY1ZzxvTHM1epJ2g0eWyM7ArMxfSNlM26MbWaorxFhEh8_92LSeBAKrw1rCiUjj4zJokNibpon6yQWmMmUGo2vuGWql6v"
		"a-JN8eKMAz8ZfgvfeClZFyHaLapqRf8zhyWx5wOU1CsKNdGr60S9CM6BUa6FW1dqwKSl9T9usMp1C9ssxVeHOPuJR5Ia_Vj1vP31kE7ZWQcUxp6yFV1OMg-HdmvvOE8HoAGlrtNz5CtOcw6TGhlXYdSazR0TkciUw9tIieumnyIofzeHbcEMK2hDXPYKUVRma7eLaTxmu3rjiTp-nnYgcU-4dGu5tJCEXkAg_Yn9qM2hA0bTH1RJ-vWZ5ps95KcfDSnPlnXd4wRjPd9QMDDdQJ-hUhYKprjkQ9IcaUxoY0ocBe87R901-x947Lrc_N1HnmNbSgQzdvIwq5mrFI1haK8dy1o8Y7G572BMKhUxBlfXiTaJ_MIvaePgFv8KsJgLDRlw-qP8YV-aRqTTV-onUbNy0yqFkOKW6SOVtijdFtn1S56w6LDvYZ_hE8OnKfh0qwkkNCbCDelHRaC0BNSNCXtJy7DAaj9W0CT10AsL1uwJUbTMhh8Jp8"
		"Pjz7g-Jmv-50MPAFxIwePZb7fUD6mDCUx4ZmZTqAonW4pKJxWIeTw4yMEmokppWz0raZSEBOdVsQ_A8qXS4sNiUGvAoUC68ni-Njjw8oEY5xpAOXORZZsdEvdiOVoRJK2UW3AZH79iHRogVwfPeTYgKhG1y1T4LFlDPaSfgklPMmz07THB0cotlINlG-XzVQpPHuq8i3FJoW5hwBYvcwryo2r10aKnz2245MPZH6xi7H9e0XQzgP5xCL-3aq-Mf9zOFU-8SK7fKCMYd0lCJW70TIoMTzt3lOoNbNEpB5sSUV2p75FnG_ZBqxTZx5mwH-RhjVlwJjQJaV2mKtWEsU2LSYZXRXAn8J8gN11WLNTclU_7h0ifhru9nm9s-Fe_lypT2DJ6hVLn6ltCHz1ujyYtqeosJV4ShZpQoGv8EG9Xkjb2yENzujhvp8lZ_WBGH6gPlysSWUmMO0pniZEzLxFU4uMFLx4bci3xC7yUNNAl-tW9-5MXPI1z"
		"Go8DykknTnO5P3WPREr2z7parz0tSI8tGJrU2RvAevBsD6432pZessizTA7c8wB.rY5eNL4BhSUs4EOb3osvyw", ENDITEM, 
		LAST);

	lr_think_time(4);

	web_url("ya.ru", 
		"URL=https://ya.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://sso.ya.ru/sync?uuid=0ed7757a-9fc6-4083-a93e-230d9543f6a5&finish=https%3A%2F%2Fya.ru", 
		"Snapshot=t331.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://yastatic.net/s3/home-static/_/de/dea813f63845fbf868c968b0a72274d6.svg", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-direct-picture/965471/M7xkzg-uqbZAb4BngvjvKA/orig", ENDITEM, 
		"Url=https://yabs.yandex.ru/resource/spacer.gif?yclid=2812325588141867007", ENDITEM, 
		LAST);

	web_custom_request("click", 
		"URL=https://ya.ru/clck/click", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://ya.ru/", 
		"Snapshot=t332.inf", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=/reqid=1736244610465829-10179296819262467497-balancer-l7leveler-kubr-yp-vla-193-BAL/path=690.2096.207/slots=1182730,0,99/vars=143=28.15.2048.3503.523,287=5,1961=0,1964=0,1965=0,-project=morda,-page=desktop.gramps_lite,-platform=desktop,-env=production,-version=2024-12-27-737.1,-blocker=,-additional=%7B%7D,143.2129=1736244608780,1701=2295,207=6709.313,-cdn=unknown/cts=1736244615701/*\r\n/reqid=1736244610465829-10179296819262467497-balancer-l7leveler-kubr-yp-vla-193-BAL/path=690.2096.2877/slots"
		"=1182730,0,99/vars=143=28.15.2048.3503.523,287=5,1961=0,1964=0,1965=0,-project=morda,-page=desktop.gramps_lite,-platform=desktop,-env=production,-version=2024-12-27-737.1,-blocker=,-additional=%7B%7D,143.2129=1736244608780,1701=2095,207.2154=6570.513,207.1428=6645.513,2877=75,-cdn=unknown/cts=1736244615701/*\r\n/reqid=1736244610465829-10179296819262467497-balancer-l7leveler-kubr-yp-vla-193-BAL/path=690.1033/slots=1182730,0,99/vars=143=28.15.2048.3503.523,287=5,1961=0,1964=0,1965=0,-project=morda,"
		"-page=desktop.gramps_lite,-platform=desktop,-env=production,-version=2024-12-27-737.1,-blocker=,-additional=%7B%7D,2129=1736244608780,1036=1,1037=0,1038=0,1039=4500,1040=315,1040.906=4815,1310.2084=0,1310.2085=2356,1310.1309=24,1310.1007=2356,2116=1,2114=1,2131=6881,2123=6857,2770=6857,2769=4501,2113=1,2112=1,2111=1,2117=4499,2120=4816,2119=4501,1484=1,-cdn=unknown/cts=1736244615702/*", 
		LAST);

	web_add_auto_header("Origin", 
		"https://ya.ru");

	web_url("3", 
		"URL=https://mc.yandex.ru/watch/3?wmode=7&page-url=https%3A%2F%2Fya.ru%2F&page-ref=https%3A%2F%2Fsso.ya.ru%2Fsync%3Fuuid%3D0ed7757a-9fc6-4083-a93e-230d9543f6a5%26finish%3Dhttps%253A%252F%252Fya.ru&charset=utf-8&ut=noindex&browser-info="
		"pv%3A1%3Avf%3Afqngs4ku2ry4ydu78wzu8osbsm7%3Afu%3A0%3Aen%3Autf-8%3Ala%3Aru-RU%3Av%3A1551%3Acn%3A1%3Adp%3A0%3Als%3A289717826898%3Ahid%3A48354699%3Az%3A180%3Ai%3A20250107131015%3Aet%3A1736244616%3Ac%3A1%3Arn%3A474592455%3Arqn%3A1%3Au%3A1736244616389225292%3Aw%3A967x497%3As%3A1600x900x24%3Ask%3A1%3Aj%3A1%3Ads%3A0%2C0%2C3%2C314%2C2%2C0%2C%2C2042%2C24%2C%2C%2C%2C6858%3Aco%3A0%3Aeu%3A0%3Ans%3A1736244608780%3Ast%3A1736244616&t=clc(0-0-0)rqnt(1)aw(1)rcm(0)yu(5677607671736244497)cdl(na)eco(32768)ti(2)", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ya.ru/", 
		"Snapshot=t333.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Origin");

	web_url("723233", 
		"URL=https://mc.yandex.ru/watch/723233?wmode=7&page-url=https%3A%2F%2Fya.ru%2F&page-ref=https%3A%2F%2Fsso.ya.ru%2Fsync%3Fuuid%3D0ed7757a-9fc6-4083-a93e-230d9543f6a5%26finish%3Dhttps%253A%252F%252Fya.ru&charset=utf-8&exp=_GlrkPO4CPNWJSRFuCyNOg&site-info=%7B%22m_content%22%3A%22big_gramps_lite%22%7D&ut=noindex&uah=che%0A0&browser-info="
		"pv%3A1%3Avf%3Afqngs4ku2ry4ydu78wzu8osbsm7%3Afu%3A0%3Aen%3Autf-8%3Ala%3Aru-RU%3Av%3A1551%3Acn%3A2%3Adp%3A0%3Als%3A772929758703%3Ahid%3A48354699%3Az%3A180%3Ai%3A20250107131016%3Aet%3A1736244616%3Ac%3A1%3Arn%3A814709170%3Arqn%3A1%3Au%3A1736244616389225292%3Aw%3A967x497%3As%3A1600x900x24%3Ask%3A1%3Aj%3A1%3Ads%3A0%2C0%2C3%2C314%2C2%2C0%2C%2C2042%2C24%2C%2C%2C%2C6858%3Aco%3A0%3Aeu%3A0%3Ans%3A1736244608780%3Aadb%3A2%3Arqnl%3A1%3Ast%3A1736244616%3At%3A%D0%AF%D0%BD%D0%B4%D0%B5%D0%BA%D1%81%20%E2%80%94%20%D0"
		"%B1%D1%8B%D1%81%D1%82%D1%80%D1%8B%D0%B9%20%D0%BF%D0%BE%D0%B8%D1%81%D0%BA%20%D0%B2%20%D0%B8%D0%BD%D1%82%D0%B5%D1%80%D0%BD%D0%B5%D1%82%D0%B5&t=gdpr(8-0)clc(0-0-0)rqnt(1)aw(1)rcm(0)yu(5677607671736244497)cdl(na)eco(2199808)ti(2)", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ya.ru/", 
		"Snapshot=t334.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("click_2", 
		"URL=https://ya.ru/clck/click", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://ya.ru/", 
		"Snapshot=t335.inf", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=/reqid=1736244610465829-10179296819262467497-balancer-l7leveler-kubr-yp-vla-193-BAL/path=690.2096.207/slots=1182730,0,99/vars=143=28.15.2048.3503.523,287=5,1961=0,1964=0,1965=0,-project=morda,-page=desktop.gramps_lite,-platform=desktop,-env=production,-version=2024-12-27-737.1,-blocker=,-additional=%7B%7D,143.2129=1736244608780,1701=1724,207=7548.313,-cdn=unknown/cts=1736244616328/*\r\n/reqid=1736244610465829-10179296819262467497-balancer-l7leveler-kubr-yp-vla-193-BAL/path=690.2096.2892/slots"
		"=1182730,0,99/vars=143=28.15.2048.3503.523,287=5,1961=0,1964=0,1965=0,-project=morda,-page=desktop.gramps_lite,-platform=desktop,-env=production,-version=2024-12-27-737.1,-blocker=,-additional=%7B%7D,2116=1.813,2114=1.813,2124=7547.413,2131=6881.513,2123=6857.813,2770=6857.813,2769=4501.613,2113=1.813,2112=1.813,2136=0,2888=navigation,2111=1.813,2126=0,2125=7548.013,1385=0,2110=0,2109=0,2117=4499.313,2120=4816.313,2119=4501.613,2322=0,76=navigate,2128=0,2127=0,-cdn=unknown/cts=1736244616329/*", 
		LAST);

	lr_end_transaction("5_transaction",LR_AUTO);

	web_add_auto_header("Origin", 
		"https://ya.ru");

	web_url("WJOejI_zOoVX2Lcj04K907DFF4qGZI2O_8xN6-vm_KvMnz7hx2KCeEDKaOvWQo0aX8E51JmGMEyP7EoomnU23buNHW1ljZPURwEDyc3qOgNiAmJHHlT61edKTO4fYLBcO2Q0WpY03Lmvk2TQ3Ri_qu0zpRPAertIP6rez6K6SuR64axW0BW-02qTG9OEG8_4OAPWIfoH7PEIR3qiR1tGTNs632FJg6mgSAF5WH0UbTv43AmU9baCCcMUGjPJq3sC", 
		"URL=https://yabs.yandex.ru/count/WJOejI_zOoVX2Lcj04K907DFF4qGZI2O_8xN6-vm_KvMnz7hx2KCeEDKaOvWQo0aX8E51JmGMEyP7EoomnU23buNHW1ljZPURwEDyc3qOgNiAmJHHlT61edKTO4fYLBcO2Q0WpY03Lmvk2TQ3Ri_qu0zpRPAertIP6rez6K6SuR64axW0BW-02qTG9OEG8_4OAPWIfoH7PEIR3qiR1tGTNs632FJg6mgSAF5WH0UbTv43AmU9baCCcMUGjPJq3sCcO6jhiDu9Il45ARnC143fal1dYA788Ks0JJrA3Ht_nkRFAByPQ4RQtW8vagbKYaZnnUixNLTn-3Hb7_FX4u25mhyUW8H_1IRZFCQfnCu3KZauNTffM-Jnxzmm2SANTb1JNW_tA85DOYE5pKVDvbAvksh72fcGeBU~2="
		"WHmejI_zOoVX2Lbm07K80CCEEKqvBLwm27YzbiaEpe0l3U8BWidlb4NO8I_rdJ7q-LpkxDb-vyuRxdoLJGLkj3WGmgFIcuY1rSCaYq77qKGZayELqbm85z0KvKmCRasvu813bm6-bapW0U1gTpxVCEamOP9amrOExebMmzw11YqzLLFsD5kVGUipP6CU29zdjlILXp5JW88XPu0HusSmNyaACOLfF4p4WEbIQ78z4HxW7_vYBd02LPXbUkcbptpP0nH0I3_sqEHCX_JV7i8fmZs_ZT5rlGZX5E6Urqxmkd_3IwpJQdGCT3eAG1446e8Q1_oH3Q2fcWlyXIe-EQ_3tjY0vg_YMInQyzhuE4G9LxWEzPMzFzX_WuB_jiKJVG00~2", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://ya.ru/", 
		"Snapshot=t336.inf", 
		"Mode=HTML", 
		LAST);

	web_url("WJOejI_zOoVX2Lcj04K907DFF4qGZI2O_8xN6-vm_KvMnz7hx2KCeEDKaOvWQo0aX8E51JmGMEyP7EoomnU23buNHW1ljZPURwEDyc3qOgNiAmJHHlT61edKTO4fYLBcO2Q0WpY03Lmvk2TQ3Ri_qu0zpRPAertIP6rez6K6SuR64axW0BW-02qTG9OEG8_4OAPWIfoH7PEIR3qiR1tGTNs632FJg6mgSAF5WH0UbTv43AmU9baCCcMUGjPJq3sC_2", 
		"URL=https://yabs.yandex.ru/count/WJOejI_zOoVX2Lcj04K907DFF4qGZI2O_8xN6-vm_KvMnz7hx2KCeEDKaOvWQo0aX8E51JmGMEyP7EoomnU23buNHW1ljZPURwEDyc3qOgNiAmJHHlT61edKTO4fYLBcO2Q0WpY03Lmvk2TQ3Ri_qu0zpRPAertIP6rez6K6SuR64axW0BW-02qTG9OEG8_4OAPWIfoH7PEIR3qiR1tGTNs632FJg6mgSAF5WH0UbTv43AmU9baCCcMUGjPJq3sCcO6jhiDu9Il45ARnC143fal1dYA788Ks0JJrA3Ht_nkRFAByPQ4RQtW8vagbKYaZnnUixNLTn-3Hb7_FX4u25mhyUW8H_1IRZFCQfnCu3KZauNTffM-Jnxzmm2SANTb1JNW_tA85DOYE5pKVDvbAvksh72fcGeBU~2="
		"WL8ejI_zOoVX2Lco02KA0FEHHKqvBLwm27YzbiaEpe0l3U8BWidlb4NO8I_rdJ7q-LpkxDb-vyuRxdoLJGLkj3WGmgFIcuY1rSCaYq77qKGZayELqbm8vRBVWoHoRioIGqA4WB4_KjULB5FK0yK4ZFqNj78U5nFNZZu2nXeiyQ7t8RpyuFKUk2O6jwPSSC2Xom1V1i04vK-mdCytJ3fCc2JPi9M3UwBLi7UWGKjFrPGzpTPdqFeCsHWCz0Ms1yBdcIrzvM7C5A1Wo1bWnFWPp5UoGanX6WyJCM2w59fSJuG7-8U_c0jCGzqno_JI2yEN_H0lCoi_3Z7OOmcU_ov5gat1ybjQr_KjaMfJiBnsWjSzcIAMkoqaR7QCHpPb49WGX730iydSRF443Fn5BcxIOyVogodEccZ-TSc7mqnr-v5Xp7rTWQyhBFjQOLz-ZVwRxOcL0G00~2", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://ya.ru/", 
		"Snapshot=t337.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}